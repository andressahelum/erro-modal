from teste import app
from flask import Flask, render_template, url_for

@app.route('/')
def hello_world():
    return render_template('base.html')